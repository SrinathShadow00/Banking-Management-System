package com.bank.service;

import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.InvalidTransactionException;
import com.bank.model.Account;
import com.bank.model.CurrentAccount;
import com.bank.model.Customer;
import com.bank.model.SavingsAccount;
import com.bank.model.Transaction;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BankService {

    private final Map<String, Customer> customers = new HashMap<>();
    private final Map<String, Account> accounts = new HashMap<>();
    private final Map<String, List<Transaction>> transactions = new HashMap<>();

    private int customerSequence = 1;
    private int accountSequence = 1000;

    public Customer registerCustomer(String name, String phone, String email) {
        if (name == null || name.isBlank()) {
            throw new InvalidTransactionException("Customer name cannot be empty.");
        }
        String customerId = "CUS-" + customerSequence++;
        Customer customer = new Customer(customerId, name.trim(), phone, email);
        customers.put(customerId, customer);
        return customer;
    }

    public Account createAccount(String customerId, String accountType, double initialDeposit) {
        Customer customer = getCustomer(customerId);
        String accountNumber = "ACC-" + accountSequence++;
        Account account;
        if ("SAVINGS".equalsIgnoreCase(accountType)) {
            account = SavingsAccount.open(accountNumber, customerId, initialDeposit);
        } else if ("CURRENT".equalsIgnoreCase(accountType)) {
            account = CurrentAccount.open(accountNumber, customerId, initialDeposit);
        } else {
            throw new InvalidTransactionException("Unknown account type: " + accountType
                    + ". Supported types are SAVINGS and CURRENT.");
        }
        accounts.put(accountNumber, account);
        customer.addAccount(account);
        transactions.putIfAbsent(accountNumber, new ArrayList<>());
        log(accountNumber, Transaction.Type.DEPOSIT, initialDeposit, account.getBalance());
        return account;
    }

    public void deposit(String accountNumber, double amount) {
        Account account = getAccount(accountNumber);
        account.deposit(amount);
        log(accountNumber, Transaction.Type.DEPOSIT, amount, account.getBalance());
    }

    public void withdraw(String accountNumber, double amount) throws InsufficientBalanceException {
        Account account = getAccount(accountNumber);
        account.withdraw(amount);
        log(accountNumber, Transaction.Type.WITHDRAWAL, amount, account.getBalance());
    }

    public void transfer(String fromAccountNumber, String toAccountNumber, double amount)
            throws InsufficientBalanceException {
        Account from = getAccount(fromAccountNumber);
        Account to = getAccount(toAccountNumber);
        from.withdraw(amount);
        log(fromAccountNumber, Transaction.Type.TRANSFER_OUT, amount, from.getBalance());
        to.deposit(amount);
        log(toAccountNumber, Transaction.Type.TRANSFER_IN, amount, to.getBalance());
    }

    public Customer getCustomer(String customerId) {
        Customer customer = customers.get(customerId);
        if (customer == null) {
            throw new InvalidTransactionException("Customer not found: " + customerId);
        }
        return customer;
    }

    public Account getAccount(String accountNumber) {
        Account account = accounts.get(accountNumber);
        if (account == null) {
            throw new InvalidTransactionException("Account not found: " + accountNumber);
        }
        return account;
    }

    public double getBalance(String accountNumber) {
        return getAccount(accountNumber).getBalance();
    }

    public List<Transaction> getStatement(String accountNumber) {
        getAccount(accountNumber);
        return new ArrayList<>(transactions.getOrDefault(accountNumber, new ArrayList<>()));
    }

    public Collection<Account> getAllAccounts() {
        return accounts.values();
    }

    public Collection<Customer> getAllCustomers() {
        return customers.values();
    }

    private void log(String accountNumber, Transaction.Type type, double amount, double balanceAfter) {
        transactions.computeIfAbsent(accountNumber, k -> new ArrayList<>())
                .add(new Transaction(accountNumber, type, amount, balanceAfter));
    }
}