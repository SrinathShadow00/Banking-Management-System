package com.bank.model;

import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.InvalidTransactionException;

public class SavingsAccount extends Account {

    private static final double MINIMUM_BALANCE = 500.0;
    private static final double INTEREST_RATE = 4.0;

    private SavingsAccount(String accountNumber, String customerId, double initialDeposit) {
        super(accountNumber, customerId, initialDeposit);
    }

    public static SavingsAccount open(String accountNumber, String customerId, double initialDeposit) {
        validateAmount(initialDeposit, "Initial deposit");
        if (initialDeposit < MINIMUM_BALANCE) {
            throw new InvalidTransactionException(
                    "Savings account requires a minimum opening deposit of " + MINIMUM_BALANCE + ".");
        }
        return new SavingsAccount(accountNumber, customerId, initialDeposit);
    }

    @Override
    public String getAccountType() {
        return "SAVINGS";
    }

    @Override
    public void withdraw(double amount) throws InsufficientBalanceException {
        validateAmount(amount, "Withdrawal amount");
        if (balance - amount < MINIMUM_BALANCE) {
            throw new InsufficientBalanceException(
                    "Cannot withdraw. Savings account must maintain a minimum balance of " + MINIMUM_BALANCE
                            + ". Current balance: " + balance);
        }
        balance -= amount;
    }

    public void applyQuarterlyInterest() {
        double interest = balance * (INTEREST_RATE / 100.0) / 4.0;
        balance += interest;
    }

    public static double getMinimumBalance() {
        return MINIMUM_BALANCE;
    }
}