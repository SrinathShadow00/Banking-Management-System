package com.bank.model;

import com.bank.exception.InvalidTransactionException;

public class CurrentAccount extends Account {

    private CurrentAccount(String accountNumber, String customerId, double initialDeposit) {
        super(accountNumber, customerId, initialDeposit);
    }

    public static CurrentAccount open(String accountNumber, String customerId, double initialDeposit) {
        validateAmount(initialDeposit, "Initial deposit");
        return new CurrentAccount(accountNumber, customerId, initialDeposit);
    }

    @Override
    public String getAccountType() {
        return "CURRENT";
    }
}