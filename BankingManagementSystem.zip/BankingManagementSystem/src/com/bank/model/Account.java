package com.bank.model;

import com.bank.exception.InsufficientBalanceException;
import com.bank.exception.InvalidTransactionException;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Account {

    protected final String accountNumber;
    protected final String customerId;
    protected double balance;
    protected final LocalDate openedDate;

    protected Account(String accountNumber, String customerId, double initialDeposit) {
        this.accountNumber = accountNumber;
        this.customerId = customerId;
        this.balance = initialDeposit;
        this.openedDate = LocalDate.now();
    }

    public abstract String getAccountType();

    public void deposit(double amount) {
        validateAmount(amount, "Deposit amount");
        balance += amount;
    }

    public void withdraw(double amount) throws InsufficientBalanceException {
        validateAmount(amount, "Withdrawal amount");
        if (balance < amount) {
            throw new InsufficientBalanceException(
                    "Insufficient balance. Available: " + balance + ", requested: " + amount);
        }
        balance -= amount;
    }

    protected static void validateAmount(double amount, String field) {
        if (amount <= 0) {
            throw new InvalidTransactionException(field + " must be greater than zero.");
        }
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getCustomerId() {
        return customerId;
    }

    public double getBalance() {
        return balance;
    }

    public LocalDate getOpenedDate() {
        return openedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Account account)) {
            return false;
        }
        return Objects.equals(accountNumber, account.accountNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber);
    }

    @Override
    public String toString() {
        return "Account [accountNumber=" + accountNumber + ", customerId=" + customerId
                + ", type=" + getAccountType() + ", balance=" + balance
                + ", openedDate=" + openedDate + "]";
    }
}