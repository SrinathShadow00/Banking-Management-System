package com.bank;

import com.bank.exception.InsufficientBalanceException;
import com.bank.model.Account;
import com.bank.model.Customer;
import com.bank.model.Transaction;
import com.bank.service.BankService;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner SCANNER = new Scanner(System.in);
    private static final BankService BANK = new BankService();

    public static void main(String[] args) {
        System.out.println("========== BANKING MANAGEMENT SYSTEM ==========");
        boolean running = true;
        while (running) {
            try {
                printMenu();
                int choice = readInt("Enter your choice: ");
                switch (choice) {
                    case 1 -> registerCustomer();
                    case 2 -> createAccount();
                    case 3 -> deposit();
                    case 4 -> withdraw();
                    case 5 -> transfer();
                    case 6 -> checkBalance();
                    case 7 -> printStatement();
                    case 8 -> listCustomers();
                    case 9 -> listAccounts();
                    case 0 -> running = false;
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        SCANNER.close();
        System.out.println("Application closed. Goodbye!");
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("---- Main Menu ----");
        System.out.println("1. Register customer");
        System.out.println("2. Open account");
        System.out.println("3. Deposit");
        System.out.println("4. Withdraw");
        System.out.println("5. Transfer between accounts");
        System.out.println("6. Check balance");
        System.out.println("7. Account statement");
        System.out.println("8. List customers");
        System.out.println("9. List all accounts");
        System.out.println("0. Exit");
    }

    private static void registerCustomer() {
        System.out.println("\n--- Register Customer ---");
        String name = readString("Name: ");
        String phone = readString("Phone: ");
        String email = readString("Email: ");
        Customer customer = BANK.registerCustomer(name, phone, email);
        System.out.println("Customer registered. Customer ID: " + customer.getCustomerId());
    }

    private static void createAccount() {
        System.out.println("\n--- Open Account ---");
        String customerId = readString("Customer ID: ");
        String type = readString("Account type (SAVINGS / CURRENT): ");
        double initialDeposit = readDouble("Initial deposit: ");
        Account account = BANK.createAccount(customerId, type, initialDeposit);
        System.out.println("Account created: " + account);
        System.out.println("Savings accounts maintain a minimum balance of "
                + com.bank.model.SavingsAccount.getMinimumBalance() + ".");
    }

    private static void deposit() {
        System.out.println("\n--- Deposit ---");
        String accountNumber = readString("Account number: ");
        double amount = readDouble("Amount: ");
        BANK.deposit(accountNumber, amount);
        System.out.println("Deposit successful. New balance: " + BANK.getBalance(accountNumber));
    }

    private static void withdraw() throws InsufficientBalanceException {
        System.out.println("\n--- Withdraw ---");
        String accountNumber = readString("Account number: ");
        double amount = readDouble("Amount: ");
        BANK.withdraw(accountNumber, amount);
        System.out.println("Withdrawal successful. New balance: " + BANK.getBalance(accountNumber));
    }

    private static void transfer() throws InsufficientBalanceException {
        System.out.println("\n--- Transfer ---");
        String from = readString("From account number: ");
        String to = readString("To account number: ");
        double amount = readDouble("Amount: ");
        BANK.transfer(from, to, amount);
        System.out.println("Transfer successful. Balance of " + from + ": " + BANK.getBalance(from));
        System.out.println("Balance of " + to + ": " + BANK.getBalance(to));
    }

    private static void checkBalance() {
        System.out.println("\n--- Check Balance ---");
        String accountNumber = readString("Account number: ");
        System.out.println("Balance: " + BANK.getBalance(accountNumber));
    }

    private static void printStatement() {
        System.out.println("\n--- Account Statement ---");
        String accountNumber = readString("Account number: ");
        List<Transaction> statement = BANK.getStatement(accountNumber);
        System.out.println("Balance: " + BANK.getBalance(accountNumber));
        if (statement.isEmpty()) {
            System.out.println("No transactions yet.");
            return;
        }
        for (Transaction transaction : statement) {
            System.out.println(transaction);
        }
    }

    private static void listCustomers() {
        System.out.println("\n--- All Customers ---");
        for (Customer customer : BANK.getAllCustomers()) {
            System.out.println(customer);
        }
    }

    private static void listAccounts() {
        System.out.println("\n--- All Accounts ---");
        for (Account account : BANK.getAllAccounts()) {
            Customer owner = BANK.getCustomer(account.getCustomerId());
            System.out.println(account + " | Owner: " + owner.getName());
        }
    }

    private static String readString(String prompt) {
        System.out.print(prompt);
        return SCANNER.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int value = SCANNER.nextInt();
                SCANNER.nextLine();
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                SCANNER.nextLine();
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double value = SCANNER.nextDouble();
                SCANNER.nextLine();
                return value;
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                SCANNER.nextLine();
            }
        }
    }
}